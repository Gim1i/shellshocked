# Propulsion Retouches

**License: Creative Commons Attribution–NonCommercial–ShareAlike 4.0 International (CC BY-NC-SA 4.0)**

**Author:** Void  
**Project:** Propulsion Retouches  
**Year:** 2025

This project is distributed under the Creative Commons Attribution–NonCommercial–ShareAlike 4.0 International License.

You are free to:  
• **Share** — copy and redistribute the material in any medium or format  
• **Adapt** — remix, transform, and build upon the material

Under the following terms:  
• **Attribution** — You must give appropriate credit, provide a link to this license, and indicate if changes were made.  
• **NonCommercial** — You may not use the material for commercial purposes.  
• **ShareAlike** — If you modify or build upon this material, you must distribute your contributions under the same license.  
• **No additional restrictions** — You may not apply legal terms or technological measures that restrict others from doing anything the license permits.

The full legal text of the CC BY-NC-SA 4.0 license is available at:  
[https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode)

A human-readable summary is available at:  
[https://creativecommons.org/licenses/by-nc-sa/4.0/](https://creativecommons.org/licenses/by-nc-sa/4.0/)